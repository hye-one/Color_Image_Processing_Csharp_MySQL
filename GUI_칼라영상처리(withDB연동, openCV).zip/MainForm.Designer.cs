﻿
namespace Day015_01_컬러영상처리_Beta1_
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.파일ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.열기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.저장ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.종료ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.dBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dB에저장ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dB에파일저장ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dB에파일로저장ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.편집ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.undoMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redoMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.잘라내기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.복사ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.붙여넣기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.화소점ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.동일이미지ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.밝기조절ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.선명도조절ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.그레이스케일ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.히스토그램그리기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.블러ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.샤프닝ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.샤프닝1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.샤프닝2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.채도변경ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.스트레치ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.압축ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.평활화ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.필터ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.파라볼라ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.솔러라이징ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.엠보싱ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.반전ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.선택영역반전ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.흑백이미지ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.포스터ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.감마변환ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.강조ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.엔드인ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.기하학변환ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.좌우반전ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.상하반전ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.회전ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.이동ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.경계검출ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.기본엣지검출ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.수직ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.수평ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.유사연산자에지검출ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.차연산자엣지검출ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.단일임계값처리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.다중임계값처리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.로버츠ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.수평ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.수직ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.수평수직ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.소벨ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.프리윗ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.라플라시안ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deNoiseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.블러ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.필터링ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.가우시안필터ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.모폴로지ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.이미지복원ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openCVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.화소점처리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.그레이스케일ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.기하학변환ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.크기조절ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.화소영역처리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.경계선검출ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.소벨ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.샤르ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.라플라시안ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.캐니ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.색상검출ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.주황ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.초록ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.블루ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.레드ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.연초록ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.다크그린ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.도형검출ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.원검출ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.색상원검출ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.모폴로지ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.자르기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.코너검출ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.카메라ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.신호등ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.신호영역자르기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.traffic_light = new System.Windows.Forms.PictureBox();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.rightSide = new System.Windows.Forms.Panel();
            this.leftSide = new System.Windows.Forms.Panel();
            this.fill_btn = new System.Windows.Forms.PictureBox();
            this.save_btn = new System.Windows.Forms.PictureBox();
            this.DBopen_btn = new System.Windows.Forms.PictureBox();
            this.bottom = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.traffic_light)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            this.rightSide.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fill_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.save_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DBopen_btn)).BeginInit();
            this.bottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.파일ToolStripMenuItem,
            this.편집ToolStripMenuItem,
            this.화소점ToolStripMenuItem,
            this.필터ToolStripMenuItem,
            this.기하학변환ToolStripMenuItem,
            this.경계검출ToolStripMenuItem,
            this.deNoiseToolStripMenuItem,
            this.이미지복원ToolStripMenuItem,
            this.openCVToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(885, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // 파일ToolStripMenuItem
            // 
            this.파일ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(61)))), ((int)(((byte)(61)))));
            this.파일ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.열기ToolStripMenuItem,
            this.저장ToolStripMenuItem,
            this.종료ToolStripMenuItem,
            this.toolStripSeparator2,
            this.dBToolStripMenuItem,
            this.dB에저장ToolStripMenuItem,
            this.dB에파일저장ToolStripMenuItem,
            this.dB에파일로저장ToolStripMenuItem});
            this.파일ToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.파일ToolStripMenuItem.Name = "파일ToolStripMenuItem";
            this.파일ToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.파일ToolStripMenuItem.Text = "파일";
            this.파일ToolStripMenuItem.DropDownOpened += new System.EventHandler(this.파일ToolStripMenuItem_DropDownOpened);
            this.파일ToolStripMenuItem.Click += new System.EventHandler(this.ㅍ일ToolStripMenuItem_Click);
            // 
            // 열기ToolStripMenuItem
            // 
            this.열기ToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.열기ToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.열기ToolStripMenuItem.Name = "열기ToolStripMenuItem";
            this.열기ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.열기ToolStripMenuItem.Text = "열기";
            this.열기ToolStripMenuItem.Click += new System.EventHandler(this.열기ToolStripMenuItem_Click);
            // 
            // 저장ToolStripMenuItem
            // 
            this.저장ToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.저장ToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.저장ToolStripMenuItem.Name = "저장ToolStripMenuItem";
            this.저장ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.저장ToolStripMenuItem.Text = "저장";
            this.저장ToolStripMenuItem.Click += new System.EventHandler(this.저장ToolStripMenuItem_Click);
            // 
            // 종료ToolStripMenuItem
            // 
            this.종료ToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.종료ToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.종료ToolStripMenuItem.Name = "종료ToolStripMenuItem";
            this.종료ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.종료ToolStripMenuItem.Text = "종료";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.toolStripSeparator2.ForeColor = System.Drawing.Color.DimGray;
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(221, 6);
            // 
            // dBToolStripMenuItem
            // 
            this.dBToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.dBToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.dBToolStripMenuItem.Name = "dBToolStripMenuItem";
            this.dBToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.dBToolStripMenuItem.Text = "DB에서 열기";
            this.dBToolStripMenuItem.Click += new System.EventHandler(this.dBToolStripMenuItem_Click);
            // 
            // dB에저장ToolStripMenuItem
            // 
            this.dB에저장ToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.dB에저장ToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.dB에저장ToolStripMenuItem.Name = "dB에저장ToolStripMenuItem";
            this.dB에저장ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.dB에저장ToolStripMenuItem.Text = "DB에 저장";
            this.dB에저장ToolStripMenuItem.Click += new System.EventHandler(this.dB에저장ToolStripMenuItem_Click);
            // 
            // dB에파일저장ToolStripMenuItem
            // 
            this.dB에파일저장ToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.dB에파일저장ToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.dB에파일저장ToolStripMenuItem.Name = "dB에파일저장ToolStripMenuItem";
            this.dB에파일저장ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.dB에파일저장ToolStripMenuItem.Text = "DB에서 파일 열기";
            this.dB에파일저장ToolStripMenuItem.Click += new System.EventHandler(this.dB에파일저장ToolStripMenuItem_Click);
            // 
            // dB에파일로저장ToolStripMenuItem
            // 
            this.dB에파일로저장ToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.dB에파일로저장ToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.dB에파일로저장ToolStripMenuItem.Name = "dB에파일로저장ToolStripMenuItem";
            this.dB에파일로저장ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.dB에파일로저장ToolStripMenuItem.Text = "DB에 파일로 저장";
            this.dB에파일로저장ToolStripMenuItem.Click += new System.EventHandler(this.dB에파일로저장ToolStripMenuItem_Click);
            // 
            // 편집ToolStripMenuItem
            // 
            this.편집ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoMenuItem,
            this.redoMenuItem,
            this.잘라내기ToolStripMenuItem,
            this.복사ToolStripMenuItem,
            this.붙여넣기ToolStripMenuItem});
            this.편집ToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.편집ToolStripMenuItem.Name = "편집ToolStripMenuItem";
            this.편집ToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.편집ToolStripMenuItem.Text = "편집";
            // 
            // undoMenuItem
            // 
            this.undoMenuItem.Name = "undoMenuItem";
            this.undoMenuItem.Size = new System.Drawing.Size(224, 26);
            this.undoMenuItem.Text = "되돌리기";
            this.undoMenuItem.Click += new System.EventHandler(this.undoToolStripMenuItem_Click);
            // 
            // redoMenuItem
            // 
            this.redoMenuItem.Name = "redoMenuItem";
            this.redoMenuItem.Size = new System.Drawing.Size(224, 26);
            this.redoMenuItem.Text = "재실행";
            this.redoMenuItem.Click += new System.EventHandler(this.redoMenuItem_Click);
            // 
            // 잘라내기ToolStripMenuItem
            // 
            this.잘라내기ToolStripMenuItem.Name = "잘라내기ToolStripMenuItem";
            this.잘라내기ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.잘라내기ToolStripMenuItem.Text = "잘라내기";
            // 
            // 복사ToolStripMenuItem
            // 
            this.복사ToolStripMenuItem.Name = "복사ToolStripMenuItem";
            this.복사ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.복사ToolStripMenuItem.Text = "복사";
            // 
            // 붙여넣기ToolStripMenuItem
            // 
            this.붙여넣기ToolStripMenuItem.Name = "붙여넣기ToolStripMenuItem";
            this.붙여넣기ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.붙여넣기ToolStripMenuItem.Text = "붙여넣기";
            // 
            // 화소점ToolStripMenuItem
            // 
            this.화소점ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.동일이미지ToolStripMenuItem,
            this.밝기조절ToolStripMenuItem,
            this.선명도조절ToolStripMenuItem,
            this.그레이스케일ToolStripMenuItem,
            this.히스토그램그리기ToolStripMenuItem,
            this.toolStripSeparator1,
            this.블러ToolStripMenuItem1,
            this.샤프닝ToolStripMenuItem,
            this.채도변경ToolStripMenuItem,
            this.스트레치ToolStripMenuItem,
            this.압축ToolStripMenuItem,
            this.평활화ToolStripMenuItem});
            this.화소점ToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.화소점ToolStripMenuItem.Name = "화소점ToolStripMenuItem";
            this.화소점ToolStripMenuItem.Size = new System.Drawing.Size(38, 24);
            this.화소점ToolStripMenuItem.Text = "색";
            // 
            // 동일이미지ToolStripMenuItem
            // 
            this.동일이미지ToolStripMenuItem.Name = "동일이미지ToolStripMenuItem";
            this.동일이미지ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.동일이미지ToolStripMenuItem.Text = "동일 이미지";
            // 
            // 밝기조절ToolStripMenuItem
            // 
            this.밝기조절ToolStripMenuItem.Name = "밝기조절ToolStripMenuItem";
            this.밝기조절ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.밝기조절ToolStripMenuItem.Text = "밝기 조절";
            this.밝기조절ToolStripMenuItem.Click += new System.EventHandler(this.밝기조절ToolStripMenuItem_Click);
            // 
            // 선명도조절ToolStripMenuItem
            // 
            this.선명도조절ToolStripMenuItem.Name = "선명도조절ToolStripMenuItem";
            this.선명도조절ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.선명도조절ToolStripMenuItem.Text = "선명도 조절";
            this.선명도조절ToolStripMenuItem.Click += new System.EventHandler(this.선명도조절ToolStripMenuItem_Click);
            // 
            // 그레이스케일ToolStripMenuItem
            // 
            this.그레이스케일ToolStripMenuItem.Name = "그레이스케일ToolStripMenuItem";
            this.그레이스케일ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.그레이스케일ToolStripMenuItem.Text = "그레이 스케일";
            this.그레이스케일ToolStripMenuItem.Click += new System.EventHandler(this.그레이스케일ToolStripMenuItem_Click);
            // 
            // 히스토그램그리기ToolStripMenuItem
            // 
            this.히스토그램그리기ToolStripMenuItem.Name = "히스토그램그리기ToolStripMenuItem";
            this.히스토그램그리기ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.히스토그램그리기ToolStripMenuItem.Text = "히스토그램 그리기";
            this.히스토그램그리기ToolStripMenuItem.Click += new System.EventHandler(this.히스토그램그리기ToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(221, 6);
            // 
            // 블러ToolStripMenuItem1
            // 
            this.블러ToolStripMenuItem1.Name = "블러ToolStripMenuItem1";
            this.블러ToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.블러ToolStripMenuItem1.Text = "블러";
            this.블러ToolStripMenuItem1.Click += new System.EventHandler(this.블러ToolStripMenuItem1_Click);
            // 
            // 샤프닝ToolStripMenuItem
            // 
            this.샤프닝ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.샤프닝1ToolStripMenuItem,
            this.샤프닝2ToolStripMenuItem});
            this.샤프닝ToolStripMenuItem.Name = "샤프닝ToolStripMenuItem";
            this.샤프닝ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.샤프닝ToolStripMenuItem.Text = "샤프닝";
            // 
            // 샤프닝1ToolStripMenuItem
            // 
            this.샤프닝1ToolStripMenuItem.Name = "샤프닝1ToolStripMenuItem";
            this.샤프닝1ToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.샤프닝1ToolStripMenuItem.Text = "샤프닝1";
            this.샤프닝1ToolStripMenuItem.Click += new System.EventHandler(this.샤프닝1ToolStripMenuItem_Click);
            // 
            // 샤프닝2ToolStripMenuItem
            // 
            this.샤프닝2ToolStripMenuItem.Name = "샤프닝2ToolStripMenuItem";
            this.샤프닝2ToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.샤프닝2ToolStripMenuItem.Text = "샤프닝2";
            this.샤프닝2ToolStripMenuItem.Click += new System.EventHandler(this.샤프닝2ToolStripMenuItem_Click);
            // 
            // 채도변경ToolStripMenuItem
            // 
            this.채도변경ToolStripMenuItem.Name = "채도변경ToolStripMenuItem";
            this.채도변경ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.채도변경ToolStripMenuItem.Text = "채도 변경";
            this.채도변경ToolStripMenuItem.Click += new System.EventHandler(this.채도변경ToolStripMenuItem_Click);
            // 
            // 스트레치ToolStripMenuItem
            // 
            this.스트레치ToolStripMenuItem.Name = "스트레치ToolStripMenuItem";
            this.스트레치ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.스트레치ToolStripMenuItem.Text = "스트레치";
            this.스트레치ToolStripMenuItem.Click += new System.EventHandler(this.스트레치ToolStripMenuItem_Click);
            // 
            // 압축ToolStripMenuItem
            // 
            this.압축ToolStripMenuItem.Name = "압축ToolStripMenuItem";
            this.압축ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.압축ToolStripMenuItem.Text = "압축";
            this.압축ToolStripMenuItem.Click += new System.EventHandler(this.압축ToolStripMenuItem_Click);
            // 
            // 평활화ToolStripMenuItem
            // 
            this.평활화ToolStripMenuItem.Name = "평활화ToolStripMenuItem";
            this.평활화ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.평활화ToolStripMenuItem.Text = "평활화";
            this.평활화ToolStripMenuItem.Click += new System.EventHandler(this.평활화ToolStripMenuItem_Click);
            // 
            // 필터ToolStripMenuItem
            // 
            this.필터ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.파라볼라ToolStripMenuItem1,
            this.솔러라이징ToolStripMenuItem1,
            this.엠보싱ToolStripMenuItem1,
            this.반전ToolStripMenuItem,
            this.흑백이미지ToolStripMenuItem,
            this.포스터ToolStripMenuItem,
            this.감마변환ToolStripMenuItem,
            this.강조ToolStripMenuItem,
            this.엔드인ToolStripMenuItem});
            this.필터ToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.필터ToolStripMenuItem.Name = "필터ToolStripMenuItem";
            this.필터ToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.필터ToolStripMenuItem.Text = "필터";
            // 
            // 파라볼라ToolStripMenuItem1
            // 
            this.파라볼라ToolStripMenuItem1.Name = "파라볼라ToolStripMenuItem1";
            this.파라볼라ToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.파라볼라ToolStripMenuItem1.Text = "파라볼라";
            this.파라볼라ToolStripMenuItem1.Click += new System.EventHandler(this.파라볼라ToolStripMenuItem1_Click);
            // 
            // 솔러라이징ToolStripMenuItem1
            // 
            this.솔러라이징ToolStripMenuItem1.Name = "솔러라이징ToolStripMenuItem1";
            this.솔러라이징ToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.솔러라이징ToolStripMenuItem1.Text = "솔러라이징";
            this.솔러라이징ToolStripMenuItem1.Click += new System.EventHandler(this.솔러라이징ToolStripMenuItem1_Click);
            // 
            // 엠보싱ToolStripMenuItem1
            // 
            this.엠보싱ToolStripMenuItem1.Name = "엠보싱ToolStripMenuItem1";
            this.엠보싱ToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.엠보싱ToolStripMenuItem1.Text = "엠보싱";
            this.엠보싱ToolStripMenuItem1.Click += new System.EventHandler(this.엠보싱ToolStripMenuItem1_Click);
            // 
            // 반전ToolStripMenuItem
            // 
            this.반전ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.선택영역반전ToolStripMenuItem});
            this.반전ToolStripMenuItem.Name = "반전ToolStripMenuItem";
            this.반전ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.반전ToolStripMenuItem.Text = "반전";
            this.반전ToolStripMenuItem.Click += new System.EventHandler(this.반전ToolStripMenuItem_Click);
            // 
            // 선택영역반전ToolStripMenuItem
            // 
            this.선택영역반전ToolStripMenuItem.Name = "선택영역반전ToolStripMenuItem";
            this.선택영역반전ToolStripMenuItem.Size = new System.Drawing.Size(182, 26);
            this.선택영역반전ToolStripMenuItem.Text = "선택영역반전";
            this.선택영역반전ToolStripMenuItem.Click += new System.EventHandler(this.선택영역반전ToolStripMenuItem_Click);
            // 
            // 흑백이미지ToolStripMenuItem
            // 
            this.흑백이미지ToolStripMenuItem.Name = "흑백이미지ToolStripMenuItem";
            this.흑백이미지ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.흑백이미지ToolStripMenuItem.Text = "흑백 이미지";
            this.흑백이미지ToolStripMenuItem.Click += new System.EventHandler(this.흑백이미지ToolStripMenuItem_Click);
            // 
            // 포스터ToolStripMenuItem
            // 
            this.포스터ToolStripMenuItem.Name = "포스터ToolStripMenuItem";
            this.포스터ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.포스터ToolStripMenuItem.Text = "포스터";
            this.포스터ToolStripMenuItem.Click += new System.EventHandler(this.포스터ToolStripMenuItem_Click);
            // 
            // 감마변환ToolStripMenuItem
            // 
            this.감마변환ToolStripMenuItem.Name = "감마변환ToolStripMenuItem";
            this.감마변환ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.감마변환ToolStripMenuItem.Text = "감마변환";
            this.감마변환ToolStripMenuItem.Click += new System.EventHandler(this.감마변환ToolStripMenuItem_Click);
            // 
            // 강조ToolStripMenuItem
            // 
            this.강조ToolStripMenuItem.Name = "강조ToolStripMenuItem";
            this.강조ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.강조ToolStripMenuItem.Text = "강조";
            this.강조ToolStripMenuItem.Click += new System.EventHandler(this.강조ToolStripMenuItem_Click);
            // 
            // 엔드인ToolStripMenuItem
            // 
            this.엔드인ToolStripMenuItem.Name = "엔드인ToolStripMenuItem";
            this.엔드인ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.엔드인ToolStripMenuItem.Text = "엔드인";
            this.엔드인ToolStripMenuItem.Click += new System.EventHandler(this.엔드인ToolStripMenuItem_Click);
            // 
            // 기하학변환ToolStripMenuItem
            // 
            this.기하학변환ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.좌우반전ToolStripMenuItem,
            this.상하반전ToolStripMenuItem,
            this.회전ToolStripMenuItem,
            this.이동ToolStripMenuItem});
            this.기하학변환ToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.기하학변환ToolStripMenuItem.Name = "기하학변환ToolStripMenuItem";
            this.기하학변환ToolStripMenuItem.Size = new System.Drawing.Size(103, 24);
            this.기하학변환ToolStripMenuItem.Text = "기하학 변환";
            // 
            // 좌우반전ToolStripMenuItem
            // 
            this.좌우반전ToolStripMenuItem.Name = "좌우반전ToolStripMenuItem";
            this.좌우반전ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.좌우반전ToolStripMenuItem.Text = "좌우반전";
            this.좌우반전ToolStripMenuItem.Click += new System.EventHandler(this.좌우반전ToolStripMenuItem_Click);
            // 
            // 상하반전ToolStripMenuItem
            // 
            this.상하반전ToolStripMenuItem.Name = "상하반전ToolStripMenuItem";
            this.상하반전ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.상하반전ToolStripMenuItem.Text = "상하반전";
            this.상하반전ToolStripMenuItem.Click += new System.EventHandler(this.상하반전ToolStripMenuItem_Click);
            // 
            // 회전ToolStripMenuItem
            // 
            this.회전ToolStripMenuItem.Name = "회전ToolStripMenuItem";
            this.회전ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.회전ToolStripMenuItem.Text = "회전";
            this.회전ToolStripMenuItem.Click += new System.EventHandler(this.회전ToolStripMenuItem_Click);
            // 
            // 이동ToolStripMenuItem
            // 
            this.이동ToolStripMenuItem.Name = "이동ToolStripMenuItem";
            this.이동ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.이동ToolStripMenuItem.Text = "이동";
            this.이동ToolStripMenuItem.Click += new System.EventHandler(this.이동ToolStripMenuItem_Click);
            // 
            // 경계검출ToolStripMenuItem
            // 
            this.경계검출ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.기본엣지검출ToolStripMenuItem,
            this.유사연산자에지검출ToolStripMenuItem,
            this.차연산자엣지검출ToolStripMenuItem,
            this.단일임계값처리ToolStripMenuItem,
            this.다중임계값처리ToolStripMenuItem,
            this.로버츠ToolStripMenuItem,
            this.소벨ToolStripMenuItem,
            this.프리윗ToolStripMenuItem,
            this.라플라시안ToolStripMenuItem,
            this.loGToolStripMenuItem,
            this.doGToolStripMenuItem});
            this.경계검출ToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.경계검출ToolStripMenuItem.Name = "경계검출ToolStripMenuItem";
            this.경계검출ToolStripMenuItem.Size = new System.Drawing.Size(88, 24);
            this.경계검출ToolStripMenuItem.Text = "경계 검출";
            // 
            // 기본엣지검출ToolStripMenuItem
            // 
            this.기본엣지검출ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.수직ToolStripMenuItem,
            this.수평ToolStripMenuItem});
            this.기본엣지검출ToolStripMenuItem.Name = "기본엣지검출ToolStripMenuItem";
            this.기본엣지검출ToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.기본엣지검출ToolStripMenuItem.Text = "기본 엣지 검출";
            // 
            // 수직ToolStripMenuItem
            // 
            this.수직ToolStripMenuItem.Name = "수직ToolStripMenuItem";
            this.수직ToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.수직ToolStripMenuItem.Text = "수직";
            this.수직ToolStripMenuItem.Click += new System.EventHandler(this.수직ToolStripMenuItem_Click);
            // 
            // 수평ToolStripMenuItem
            // 
            this.수평ToolStripMenuItem.Name = "수평ToolStripMenuItem";
            this.수평ToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.수평ToolStripMenuItem.Text = "수평";
            this.수평ToolStripMenuItem.Click += new System.EventHandler(this.수평ToolStripMenuItem_Click);
            // 
            // 유사연산자에지검출ToolStripMenuItem
            // 
            this.유사연산자에지검출ToolStripMenuItem.Name = "유사연산자에지검출ToolStripMenuItem";
            this.유사연산자에지검출ToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.유사연산자에지검출ToolStripMenuItem.Text = "유사 연산자 에지 검출";
            this.유사연산자에지검출ToolStripMenuItem.Click += new System.EventHandler(this.유사연산자에지검출ToolStripMenuItem_Click);
            // 
            // 차연산자엣지검출ToolStripMenuItem
            // 
            this.차연산자엣지검출ToolStripMenuItem.Name = "차연산자엣지검출ToolStripMenuItem";
            this.차연산자엣지검출ToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.차연산자엣지검출ToolStripMenuItem.Text = "차 연산자 엣지 검출";
            // 
            // 단일임계값처리ToolStripMenuItem
            // 
            this.단일임계값처리ToolStripMenuItem.Name = "단일임계값처리ToolStripMenuItem";
            this.단일임계값처리ToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.단일임계값처리ToolStripMenuItem.Text = "단일 임계값 처리";
            // 
            // 다중임계값처리ToolStripMenuItem
            // 
            this.다중임계값처리ToolStripMenuItem.Name = "다중임계값처리ToolStripMenuItem";
            this.다중임계값처리ToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.다중임계값처리ToolStripMenuItem.Text = "다중 임계값 처리";
            // 
            // 로버츠ToolStripMenuItem
            // 
            this.로버츠ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.수평ToolStripMenuItem1,
            this.수직ToolStripMenuItem1,
            this.수평수직ToolStripMenuItem});
            this.로버츠ToolStripMenuItem.Name = "로버츠ToolStripMenuItem";
            this.로버츠ToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.로버츠ToolStripMenuItem.Text = "로버츠 ";
            this.로버츠ToolStripMenuItem.Click += new System.EventHandler(this.로버츠ToolStripMenuItem_Click);
            // 
            // 수평ToolStripMenuItem1
            // 
            this.수평ToolStripMenuItem1.Name = "수평ToolStripMenuItem1";
            this.수평ToolStripMenuItem1.Size = new System.Drawing.Size(128, 26);
            this.수평ToolStripMenuItem1.Text = "열";
            this.수평ToolStripMenuItem1.Click += new System.EventHandler(this.수평ToolStripMenuItem1_Click);
            // 
            // 수직ToolStripMenuItem1
            // 
            this.수직ToolStripMenuItem1.Name = "수직ToolStripMenuItem1";
            this.수직ToolStripMenuItem1.Size = new System.Drawing.Size(128, 26);
            this.수직ToolStripMenuItem1.Text = "행";
            this.수직ToolStripMenuItem1.Click += new System.EventHandler(this.수직ToolStripMenuItem1_Click);
            // 
            // 수평수직ToolStripMenuItem
            // 
            this.수평수직ToolStripMenuItem.Name = "수평수직ToolStripMenuItem";
            this.수평수직ToolStripMenuItem.Size = new System.Drawing.Size(128, 26);
            this.수평수직ToolStripMenuItem.Text = "행/열";
            this.수평수직ToolStripMenuItem.Click += new System.EventHandler(this.수평수직ToolStripMenuItem_Click);
            // 
            // 소벨ToolStripMenuItem
            // 
            this.소벨ToolStripMenuItem.Name = "소벨ToolStripMenuItem";
            this.소벨ToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.소벨ToolStripMenuItem.Text = "소벨";
            // 
            // 프리윗ToolStripMenuItem
            // 
            this.프리윗ToolStripMenuItem.Name = "프리윗ToolStripMenuItem";
            this.프리윗ToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.프리윗ToolStripMenuItem.Text = "프리윗";
            // 
            // 라플라시안ToolStripMenuItem
            // 
            this.라플라시안ToolStripMenuItem.Name = "라플라시안ToolStripMenuItem";
            this.라플라시안ToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.라플라시안ToolStripMenuItem.Text = "라플라시안";
            this.라플라시안ToolStripMenuItem.Click += new System.EventHandler(this.라플라시안ToolStripMenuItem_Click);
            // 
            // loGToolStripMenuItem
            // 
            this.loGToolStripMenuItem.Name = "loGToolStripMenuItem";
            this.loGToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.loGToolStripMenuItem.Text = "LoG";
            // 
            // doGToolStripMenuItem
            // 
            this.doGToolStripMenuItem.Name = "doGToolStripMenuItem";
            this.doGToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.doGToolStripMenuItem.Text = "DoG";
            // 
            // deNoiseToolStripMenuItem
            // 
            this.deNoiseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.블러ToolStripMenuItem,
            this.필터링ToolStripMenuItem,
            this.모폴로지ToolStripMenuItem});
            this.deNoiseToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.deNoiseToolStripMenuItem.Name = "deNoiseToolStripMenuItem";
            this.deNoiseToolStripMenuItem.Size = new System.Drawing.Size(86, 24);
            this.deNoiseToolStripMenuItem.Text = "De-Noise";
            this.deNoiseToolStripMenuItem.Click += new System.EventHandler(this.deNoiseToolStripMenuItem_Click);
            // 
            // 블러ToolStripMenuItem
            // 
            this.블러ToolStripMenuItem.Name = "블러ToolStripMenuItem";
            this.블러ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.블러ToolStripMenuItem.Text = "블러";
            this.블러ToolStripMenuItem.Click += new System.EventHandler(this.블러ToolStripMenuItem_Click);
            // 
            // 필터링ToolStripMenuItem
            // 
            this.필터링ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.가우시안필터ToolStripMenuItem});
            this.필터링ToolStripMenuItem.Name = "필터링ToolStripMenuItem";
            this.필터링ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.필터링ToolStripMenuItem.Text = "필터링";
            this.필터링ToolStripMenuItem.Click += new System.EventHandler(this.필터링ToolStripMenuItem_Click);
            // 
            // 가우시안필터ToolStripMenuItem
            // 
            this.가우시안필터ToolStripMenuItem.Name = "가우시안필터ToolStripMenuItem";
            this.가우시안필터ToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.가우시안필터ToolStripMenuItem.Text = "가우시안 필터";
            this.가우시안필터ToolStripMenuItem.Click += new System.EventHandler(this.가우시안필터ToolStripMenuItem_Click);
            // 
            // 모폴로지ToolStripMenuItem
            // 
            this.모폴로지ToolStripMenuItem.Name = "모폴로지ToolStripMenuItem";
            this.모폴로지ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.모폴로지ToolStripMenuItem.Text = "모폴로지";
            // 
            // 이미지복원ToolStripMenuItem
            // 
            this.이미지복원ToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.이미지복원ToolStripMenuItem.Name = "이미지복원ToolStripMenuItem";
            this.이미지복원ToolStripMenuItem.Size = new System.Drawing.Size(103, 24);
            this.이미지복원ToolStripMenuItem.Text = "이미지 복원";
            // 
            // openCVToolStripMenuItem
            // 
            this.openCVToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.화소점처리ToolStripMenuItem,
            this.기하학변환ToolStripMenuItem1,
            this.화소영역처리ToolStripMenuItem,
            this.경계선검출ToolStripMenuItem,
            this.색상검출ToolStripMenuItem,
            this.도형검출ToolStripMenuItem,
            this.모폴로지ToolStripMenuItem1,
            this.자르기ToolStripMenuItem,
            this.코너검출ToolStripMenuItem,
            this.카메라ToolStripMenuItem,
            this.신호등ToolStripMenuItem});
            this.openCVToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.openCVToolStripMenuItem.Name = "openCVToolStripMenuItem";
            this.openCVToolStripMenuItem.Size = new System.Drawing.Size(81, 24);
            this.openCVToolStripMenuItem.Text = "OpenCV";
            // 
            // 화소점처리ToolStripMenuItem
            // 
            this.화소점처리ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.그레이스케일ToolStripMenuItem1});
            this.화소점처리ToolStripMenuItem.Name = "화소점처리ToolStripMenuItem";
            this.화소점처리ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.화소점처리ToolStripMenuItem.Text = "화소 점 처리";
            // 
            // 그레이스케일ToolStripMenuItem1
            // 
            this.그레이스케일ToolStripMenuItem1.Name = "그레이스케일ToolStripMenuItem1";
            this.그레이스케일ToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.그레이스케일ToolStripMenuItem1.Text = "그레이 스케일";
            this.그레이스케일ToolStripMenuItem1.Click += new System.EventHandler(this.그레이스케일ToolStripMenuItem1_Click);
            // 
            // 기하학변환ToolStripMenuItem1
            // 
            this.기하학변환ToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.크기조절ToolStripMenuItem});
            this.기하학변환ToolStripMenuItem1.Name = "기하학변환ToolStripMenuItem1";
            this.기하학변환ToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.기하학변환ToolStripMenuItem1.Text = "기하학 변환";
            this.기하학변환ToolStripMenuItem1.Click += new System.EventHandler(this.기하학변환ToolStripMenuItem1_Click);
            // 
            // 크기조절ToolStripMenuItem
            // 
            this.크기조절ToolStripMenuItem.Name = "크기조절ToolStripMenuItem";
            this.크기조절ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.크기조절ToolStripMenuItem.Text = "크기 조절";
            this.크기조절ToolStripMenuItem.Click += new System.EventHandler(this.크기조절ToolStripMenuItem_Click);
            // 
            // 화소영역처리ToolStripMenuItem
            // 
            this.화소영역처리ToolStripMenuItem.Name = "화소영역처리ToolStripMenuItem";
            this.화소영역처리ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.화소영역처리ToolStripMenuItem.Text = "화소 영역 처리";
            // 
            // 경계선검출ToolStripMenuItem
            // 
            this.경계선검출ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.소벨ToolStripMenuItem1,
            this.샤르ToolStripMenuItem,
            this.라플라시안ToolStripMenuItem1,
            this.캐니ToolStripMenuItem});
            this.경계선검출ToolStripMenuItem.Name = "경계선검출ToolStripMenuItem";
            this.경계선검출ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.경계선검출ToolStripMenuItem.Text = "경계선 검출";
            // 
            // 소벨ToolStripMenuItem1
            // 
            this.소벨ToolStripMenuItem1.Name = "소벨ToolStripMenuItem1";
            this.소벨ToolStripMenuItem1.Size = new System.Drawing.Size(167, 26);
            this.소벨ToolStripMenuItem1.Text = "소벨";
            this.소벨ToolStripMenuItem1.Click += new System.EventHandler(this.소벨ToolStripMenuItem1_Click);
            // 
            // 샤르ToolStripMenuItem
            // 
            this.샤르ToolStripMenuItem.Name = "샤르ToolStripMenuItem";
            this.샤르ToolStripMenuItem.Size = new System.Drawing.Size(167, 26);
            this.샤르ToolStripMenuItem.Text = "샤르";
            this.샤르ToolStripMenuItem.Click += new System.EventHandler(this.샤르ToolStripMenuItem_Click);
            // 
            // 라플라시안ToolStripMenuItem1
            // 
            this.라플라시안ToolStripMenuItem1.Name = "라플라시안ToolStripMenuItem1";
            this.라플라시안ToolStripMenuItem1.Size = new System.Drawing.Size(167, 26);
            this.라플라시안ToolStripMenuItem1.Text = "라플라시안";
            this.라플라시안ToolStripMenuItem1.Click += new System.EventHandler(this.라플라시안ToolStripMenuItem1_Click);
            // 
            // 캐니ToolStripMenuItem
            // 
            this.캐니ToolStripMenuItem.Name = "캐니ToolStripMenuItem";
            this.캐니ToolStripMenuItem.Size = new System.Drawing.Size(167, 26);
            this.캐니ToolStripMenuItem.Text = "캐니";
            this.캐니ToolStripMenuItem.Click += new System.EventHandler(this.캐니ToolStripMenuItem_Click);
            // 
            // 색상검출ToolStripMenuItem
            // 
            this.색상검출ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.주황ToolStripMenuItem,
            this.초록ToolStripMenuItem,
            this.블루ToolStripMenuItem,
            this.레드ToolStripMenuItem,
            this.연초록ToolStripMenuItem,
            this.다크그린ToolStripMenuItem});
            this.색상검출ToolStripMenuItem.Name = "색상검출ToolStripMenuItem";
            this.색상검출ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.색상검출ToolStripMenuItem.Text = "색상 검출";
            this.색상검출ToolStripMenuItem.Click += new System.EventHandler(this.색상검출ToolStripMenuItem_Click);
            // 
            // 주황ToolStripMenuItem
            // 
            this.주황ToolStripMenuItem.Name = "주황ToolStripMenuItem";
            this.주황ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.주황ToolStripMenuItem.Text = "주황";
            // 
            // 초록ToolStripMenuItem
            // 
            this.초록ToolStripMenuItem.Name = "초록ToolStripMenuItem";
            this.초록ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.초록ToolStripMenuItem.Text = "초록";
            this.초록ToolStripMenuItem.Click += new System.EventHandler(this.초록ToolStripMenuItem_Click);
            // 
            // 블루ToolStripMenuItem
            // 
            this.블루ToolStripMenuItem.Name = "블루ToolStripMenuItem";
            this.블루ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.블루ToolStripMenuItem.Text = "블루";
            this.블루ToolStripMenuItem.Click += new System.EventHandler(this.블루ToolStripMenuItem_Click);
            // 
            // 레드ToolStripMenuItem
            // 
            this.레드ToolStripMenuItem.Name = "레드ToolStripMenuItem";
            this.레드ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.레드ToolStripMenuItem.Text = "레드";
            this.레드ToolStripMenuItem.Click += new System.EventHandler(this.레드ToolStripMenuItem_Click);
            // 
            // 연초록ToolStripMenuItem
            // 
            this.연초록ToolStripMenuItem.Name = "연초록ToolStripMenuItem";
            this.연초록ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.연초록ToolStripMenuItem.Text = "연초록";
            this.연초록ToolStripMenuItem.Click += new System.EventHandler(this.연초록ToolStripMenuItem_Click);
            // 
            // 다크그린ToolStripMenuItem
            // 
            this.다크그린ToolStripMenuItem.Name = "다크그린ToolStripMenuItem";
            this.다크그린ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.다크그린ToolStripMenuItem.Text = "다크그린";
            this.다크그린ToolStripMenuItem.Click += new System.EventHandler(this.다크그린ToolStripMenuItem_Click);
            // 
            // 도형검출ToolStripMenuItem
            // 
            this.도형검출ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.원검출ToolStripMenuItem,
            this.색상원검출ToolStripMenuItem});
            this.도형검출ToolStripMenuItem.Name = "도형검출ToolStripMenuItem";
            this.도형검출ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.도형검출ToolStripMenuItem.Text = "도형 검출";
            // 
            // 원검출ToolStripMenuItem
            // 
            this.원검출ToolStripMenuItem.Name = "원검출ToolStripMenuItem";
            this.원검출ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.원검출ToolStripMenuItem.Text = "원 검출";
            this.원검출ToolStripMenuItem.Click += new System.EventHandler(this.원검출ToolStripMenuItem_Click);
            // 
            // 색상원검출ToolStripMenuItem
            // 
            this.색상원검출ToolStripMenuItem.Name = "색상원검출ToolStripMenuItem";
            this.색상원검출ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.색상원검출ToolStripMenuItem.Text = "색상 원 검출";
            this.색상원검출ToolStripMenuItem.Click += new System.EventHandler(this.색상원검출ToolStripMenuItem_Click);
            // 
            // 모폴로지ToolStripMenuItem1
            // 
            this.모폴로지ToolStripMenuItem1.Name = "모폴로지ToolStripMenuItem1";
            this.모폴로지ToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.모폴로지ToolStripMenuItem1.Text = "모폴로지";
            this.모폴로지ToolStripMenuItem1.Click += new System.EventHandler(this.모폴로지ToolStripMenuItem1_Click);
            // 
            // 자르기ToolStripMenuItem
            // 
            this.자르기ToolStripMenuItem.Name = "자르기ToolStripMenuItem";
            this.자르기ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.자르기ToolStripMenuItem.Text = "자르기";
            this.자르기ToolStripMenuItem.Click += new System.EventHandler(this.자르기ToolStripMenuItem_Click);
            // 
            // 코너검출ToolStripMenuItem
            // 
            this.코너검출ToolStripMenuItem.Name = "코너검출ToolStripMenuItem";
            this.코너검출ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.코너검출ToolStripMenuItem.Text = "코너 검출";
            this.코너검출ToolStripMenuItem.Click += new System.EventHandler(this.코너검출ToolStripMenuItem_Click);
            // 
            // 카메라ToolStripMenuItem
            // 
            this.카메라ToolStripMenuItem.Name = "카메라ToolStripMenuItem";
            this.카메라ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.카메라ToolStripMenuItem.Text = "카메라";
            this.카메라ToolStripMenuItem.Click += new System.EventHandler(this.카메라ToolStripMenuItem_Click);
            // 
            // 신호등ToolStripMenuItem
            // 
            this.신호등ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.신호영역자르기ToolStripMenuItem});
            this.신호등ToolStripMenuItem.Name = "신호등ToolStripMenuItem";
            this.신호등ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.신호등ToolStripMenuItem.Text = "신호등";
            this.신호등ToolStripMenuItem.Click += new System.EventHandler(this.신호등ToolStripMenuItem_Click);
            // 
            // 신호영역자르기ToolStripMenuItem
            // 
            this.신호영역자르기ToolStripMenuItem.Name = "신호영역자르기ToolStripMenuItem";
            this.신호영역자르기ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.신호영역자르기ToolStripMenuItem.Text = "신호영역 자르기";
            this.신호영역자르기ToolStripMenuItem.Click += new System.EventHandler(this.신호영역자르기ToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3});
            this.statusStrip1.Location = new System.Drawing.Point(0, 585);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(885, 26);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(14, 20);
            this.toolStripStatusLabel1.Text = " ";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(14, 20);
            this.toolStripStatusLabel2.Text = " ";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(14, 20);
            this.toolStripStatusLabel3.Text = " ";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // trackBar1
            // 
            this.trackBar1.LargeChange = 1;
            this.trackBar1.Location = new System.Drawing.Point(14, 97);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Minimum = -100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(206, 56);
            this.trackBar1.TabIndex = 3;
            this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            this.trackBar1.ValueChanged += new System.EventHandler(this.trackBar1_ValueChanged);
            this.trackBar1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.trackBar1_MouseDown);
            this.trackBar1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.trackBar1_MouseUp);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(221, 97);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(54, 25);
            this.textBox1.TabIndex = 4;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pictureBox1.Location = new System.Drawing.Point(117, 49);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(410, 412);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(317, 15);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(79, 82);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(90, 237);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(47, 42);
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(37, 237);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(47, 42);
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(221, 159);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(54, 25);
            this.textBox2.TabIndex = 4;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(143, 237);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(47, 42);
            this.pictureBox5.TabIndex = 10;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(196, 237);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(47, 42);
            this.pictureBox6.TabIndex = 10;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // traffic_light
            // 
            this.traffic_light.Image = ((System.Drawing.Image)(resources.GetObject("traffic_light.Image")));
            this.traffic_light.Location = new System.Drawing.Point(409, 15);
            this.traffic_light.Name = "traffic_light";
            this.traffic_light.Size = new System.Drawing.Size(79, 82);
            this.traffic_light.TabIndex = 12;
            this.traffic_light.TabStop = false;
            this.traffic_light.Click += new System.EventHandler(this.traffic_light_Click);
            // 
            // trackBar2
            // 
            this.trackBar2.LargeChange = 1;
            this.trackBar2.Location = new System.Drawing.Point(14, 159);
            this.trackBar2.Maximum = 20;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(206, 56);
            this.trackBar2.TabIndex = 13;
            this.trackBar2.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar2.Value = 10;
            this.trackBar2.Scroll += new System.EventHandler(this.trackBar2_Scroll);
            this.trackBar2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.trackBar2_MouseDown);
            this.trackBar2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.trackBar2_MouseUp);
            // 
            // rightSide
            // 
            this.rightSide.Controls.Add(this.trackBar1);
            this.rightSide.Controls.Add(this.trackBar2);
            this.rightSide.Controls.Add(this.pictureBox4);
            this.rightSide.Controls.Add(this.textBox1);
            this.rightSide.Controls.Add(this.pictureBox6);
            this.rightSide.Controls.Add(this.pictureBox5);
            this.rightSide.Controls.Add(this.textBox2);
            this.rightSide.Controls.Add(this.pictureBox3);
            this.rightSide.Dock = System.Windows.Forms.DockStyle.Right;
            this.rightSide.Location = new System.Drawing.Point(578, 28);
            this.rightSide.Name = "rightSide";
            this.rightSide.Size = new System.Drawing.Size(307, 557);
            this.rightSide.TabIndex = 14;
            // 
            // leftSide
            // 
            this.leftSide.Dock = System.Windows.Forms.DockStyle.Left;
            this.leftSide.Location = new System.Drawing.Point(0, 28);
            this.leftSide.Name = "leftSide";
            this.leftSide.Size = new System.Drawing.Size(78, 557);
            this.leftSide.TabIndex = 15;
            this.leftSide.Paint += new System.Windows.Forms.PaintEventHandler(this.leftSide_Paint);
            // 
            // fill_btn
            // 
            this.fill_btn.Image = ((System.Drawing.Image)(resources.GetObject("fill_btn.Image")));
            this.fill_btn.Location = new System.Drawing.Point(25, 17);
            this.fill_btn.Name = "fill_btn";
            this.fill_btn.Size = new System.Drawing.Size(96, 80);
            this.fill_btn.TabIndex = 13;
            this.fill_btn.TabStop = false;
            this.fill_btn.Click += new System.EventHandler(this.fill_btn_Click);
            // 
            // save_btn
            // 
            this.save_btn.Image = ((System.Drawing.Image)(resources.GetObject("save_btn.Image")));
            this.save_btn.Location = new System.Drawing.Point(127, 17);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(78, 80);
            this.save_btn.TabIndex = 14;
            this.save_btn.TabStop = false;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // DBopen_btn
            // 
            this.DBopen_btn.Image = ((System.Drawing.Image)(resources.GetObject("DBopen_btn.Image")));
            this.DBopen_btn.Location = new System.Drawing.Point(220, 15);
            this.DBopen_btn.Name = "DBopen_btn";
            this.DBopen_btn.Size = new System.Drawing.Size(78, 82);
            this.DBopen_btn.TabIndex = 15;
            this.DBopen_btn.TabStop = false;
            this.DBopen_btn.Click += new System.EventHandler(this.DBopen_btn_Click);
            // 
            // bottom
            // 
            this.bottom.Controls.Add(this.traffic_light);
            this.bottom.Controls.Add(this.pictureBox2);
            this.bottom.Controls.Add(this.DBopen_btn);
            this.bottom.Controls.Add(this.fill_btn);
            this.bottom.Controls.Add(this.save_btn);
            this.bottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bottom.Location = new System.Drawing.Point(78, 467);
            this.bottom.Name = "bottom";
            this.bottom.Size = new System.Drawing.Size(500, 118);
            this.bottom.TabIndex = 16;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(885, 611);
            this.Controls.Add(this.bottom);
            this.Controls.Add(this.leftSide);
            this.Controls.Add(this.rightSide);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "컬러 영상처리(ver3.0)";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.traffic_light)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            this.rightSide.ResumeLayout(false);
            this.rightSide.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fill_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.save_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DBopen_btn)).EndInit();
            this.bottom.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem 파일ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 열기ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 저장ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 종료ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 화소점ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 동일이미지ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 밝기조절ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 그레이스케일ToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem 히스토그램그리기ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 편집ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem undoMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redoMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 잘라내기ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 복사ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 붙여넣기ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 필터ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 경계검출ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem 기하학변환ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 좌우반전ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 상하반전ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 회전ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 이동ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 기본엣지검출ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 수직ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 수평ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 유사연산자에지검출ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 차연산자엣지검출ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 단일임계값처리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 다중임계값처리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 로버츠ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 소벨ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 프리윗ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 라플라시안ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deNoiseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 블러ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 필터링ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 모폴로지ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 이미지복원ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 블러ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 샤프닝ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 샤프닝1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 샤프닝2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 채도변경ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 파라볼라ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 솔러라이징ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 엠보싱ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 반전ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 흑백이미지ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 선명도조절ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 포스터ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 감마변환ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 스트레치ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 압축ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 강조ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 엔드인ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 수평ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 수직ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 수평수직ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 평활화ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 가우시안필터ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 선택영역반전ToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripMenuItem dBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dB에저장ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem dB에파일저장ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dB에파일로저장ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openCVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 화소점처리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 그레이스케일ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 기하학변환ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 화소영역처리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 경계선검출ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 소벨ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 샤르ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 라플라시안ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 캐니ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 크기조절ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 색상검출ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 주황ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 초록ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 블루ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 레드ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 도형검출ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 원검출ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 모폴로지ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 자르기ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 색상원검출ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 코너검출ToolStripMenuItem;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem 카메라ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 신호등ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 신호영역자르기ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 연초록ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 다크그린ToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox traffic_light;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.Panel rightSide;
        private System.Windows.Forms.Panel leftSide;
        private System.Windows.Forms.PictureBox DBopen_btn;
        private System.Windows.Forms.PictureBox save_btn;
        private System.Windows.Forms.PictureBox fill_btn;
        private System.Windows.Forms.Panel bottom;
    }
}

